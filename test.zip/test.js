lang = document.getElementsByClassName('table table-sm')
console.log("Language "+lang)     

for(i=0;i<lang.length;i++){
    console.log("CODE "+i)     
}
